<template>
  <router-view/>
</template>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

*{
  box-sizing: border-box;
  margin: 0;
  padding: 0;
  font-family: Noto Sans SC;
  font-style: normal;
  font-weight: 400;

}

body{
  background-color: #f3f3f3;
}

</style>
