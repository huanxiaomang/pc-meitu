<template>
    <div class="d">
        <div class="four">404</div>
        <p>页面未找到</p>
    </div>
    

</template>

<style scoped>
.four{
    font-family: Noto Sans SC;
    font-style: normal;
    font-weight: 500;
    font-size: 60px;

}
.d{
    text-align: center;
    width: 500px;
    height: 300px;
    margin: 20% auto;
}
</style>