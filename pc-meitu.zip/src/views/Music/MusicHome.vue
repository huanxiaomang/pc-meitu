<template>
<MusicSearch />
</template>

<script>
import MusicSearch from '@/components/music/MusicSearch.vue';

export default {


    components:{
        MusicSearch
    }
}
</script>

<style lang="less" scoped>

</style>