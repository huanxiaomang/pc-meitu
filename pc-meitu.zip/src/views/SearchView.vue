<template>
    <HomeHeader />
    <search />
</template>

<script>
import HomeHeader from '@/components/home/HomeHeader.vue';
import search from '@/components/search/search.vue';

export default {

    components:{
        HomeHeader,search
    }

}
</script>

<style lang="less" scoped>

</style>